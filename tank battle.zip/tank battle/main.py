import pygame
import sys
from src.game import Game
from src.language_manager import LanguageManager

class TankBattleApp:
    def __init__(self):
        pygame.init()
        pygame.mixer.init()
        self.screen_width = 1200
        self.screen_height = 800
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        pygame.display.set_caption("Tank Battle")
        self.clock = pygame.time.Clock()
        self.fps = 60
        self.language_manager = LanguageManager()
        self.game = Game(self.screen, self.language_manager)
        self.running = True
        
    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_F1:
                    print("Controls: Player 1 - WASD + Space, Player 2 - Arrow Keys + Enter")
            self.game.handle_event(event)
    
    def update(self):
        dt = self.clock.tick(self.fps) / 1000.0
        self.game.update(dt)
    
    def render(self):
        self.screen.fill((50, 50, 50))
        self.game.render(self.screen)
        pygame.display.flip()
    
    def run(self):
        print("Game Starting...")
        
        while self.running:
            self.handle_events()
            self.update()
            self.render()
        
        pygame.quit()
        sys.exit()

def main():
    app = TankBattleApp()
    app.run()

if __name__ == "__main__":
    main()
