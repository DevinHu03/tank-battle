import pygame
import math
import random
from typing import Tuple
from enum import Enum

class PowerUpType(Enum):
    HEALTH = "health"
    SPEED = "speed"
    DAMAGE = "damage"
    RAPID_FIRE = "rapid_fire"
    SHIELD = "shield"

class PowerUp:
    def __init__(self, x: float, y: float, powerup_type: PowerUpType = None):
        self.x = x
        self.y = y
        self.radius = 15
        self.alive = True
        self.lifetime = 0.0
        self.max_lifetime = 10.0
        if powerup_type is None:
            self.powerup_type = random.choice(list(PowerUpType))
        else:
            self.powerup_type = powerup_type
        self.rotation = 0.0
        self.bob_offset = 0.0
        self.bob_speed = 3.0
        self.pulse_scale = 1.0
        self.setup_powerup_properties()
    
    def setup_powerup_properties(self):
        if self.powerup_type == PowerUpType.HEALTH:
            self.color = (0, 255, 0)
            self.symbol = "+"
            self.effect_value = 50
        elif self.powerup_type == PowerUpType.SPEED:
            self.color = (0, 255, 255)
            self.symbol = ">"
            self.effect_value = 1.5
        elif self.powerup_type == PowerUpType.DAMAGE:
            self.color = (255, 0, 0)
            self.symbol = "!"
            self.effect_value = 2.0
        elif self.powerup_type == PowerUpType.RAPID_FIRE:
            self.color = (255, 255, 0)
            self.symbol = "*"
            self.effect_value = 0.5
        elif self.powerup_type == PowerUpType.SHIELD:
            self.color = (128, 0, 128)
            self.symbol = "O"
            self.effect_value = 5.0
    
    def update(self, dt: float):
        if not self.alive:
            return
        self.lifetime += dt
        if self.lifetime >= self.max_lifetime:
            self.alive = False
        self.rotation += 90 * dt
        self.bob_offset = math.sin(self.lifetime * self.bob_speed) * 5
        if self.lifetime > self.max_lifetime * 0.8:
            pulse_frequency = 5.0
            self.pulse_scale = 1.0 + 0.3 * math.sin(self.lifetime * pulse_frequency)
        else:
            self.pulse_scale = 1.0
    
    def apply_effect(self, tank):
        if self.powerup_type == PowerUpType.HEALTH:
            tank.heal(self.effect_value)
            print(f"Health restored: +{self.effect_value}")
        
        elif self.powerup_type == PowerUpType.SPEED:
            tank.speed *= self.effect_value
            print(f"Speed boost: x{self.effect_value}")
        
        elif self.powerup_type == PowerUpType.DAMAGE:
            tank.bullet_damage = int(tank.bullet_damage * self.effect_value)
            print(f"Damage boost: x{self.effect_value}")
        
        elif self.powerup_type == PowerUpType.RAPID_FIRE:
            tank.shot_cooldown *= self.effect_value
            print(f"Rapid fire: cooldown x{self.effect_value}")
        
        elif self.powerup_type == PowerUpType.SHIELD:
            print(f"Shield activated for {self.effect_value} seconds")
    
    def render(self, screen: pygame.Surface):
        if not self.alive:
            return
        render_y = self.y + self.bob_offset
        alpha = 255
        if self.lifetime > self.max_lifetime * 0.8:
            blink_speed = 10.0
            alpha = int(255 * (0.5 + 0.5 * math.sin(self.lifetime * blink_speed)))
        size = int(self.radius * 2 * self.pulse_scale)
        powerup_surface = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
        center = (size, size)
        color_with_alpha = (*self.color, alpha)
        pygame.draw.circle(powerup_surface, color_with_alpha, center, size)
        pygame.draw.circle(powerup_surface, (255, 255, 255, alpha), center, size, 3)
        font = pygame.font.Font(None, int(size * 1.2))
        text_surface = font.render(self.symbol, True, (255, 255, 255))
        text_surface.set_alpha(alpha)
        text_rect = text_surface.get_rect(center=center)
        powerup_surface.blit(text_surface, text_rect)
        rotated_surface = pygame.transform.rotate(powerup_surface, self.rotation)
        rect = rotated_surface.get_rect()
        rect.center = (self.x, render_y)
        screen.blit(rotated_surface, rect)
        self.render_aura(screen, render_y, alpha)
    
    def render_aura(self, screen: pygame.Surface, y: float, alpha: int):
        aura_radius = int(self.radius * 1.5 * self.pulse_scale)
        aura_surface = pygame.Surface((aura_radius * 4, aura_radius * 4), pygame.SRCALPHA)
        for i in range(3):
            radius = aura_radius - i * 5
            if radius > 0:
                aura_alpha = alpha // (3 + i * 2)
                aura_color = (*self.color, aura_alpha)
                center = (aura_radius * 2, aura_radius * 2)
                pygame.draw.circle(aura_surface, aura_color, center, radius, 2)
        rect = aura_surface.get_rect()
        rect.center = (self.x, y)
        screen.blit(aura_surface, rect)
