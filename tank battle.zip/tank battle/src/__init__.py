__version__ = "1.0.0"
__author__ = "Tank Battle Team"
__description__ = "A beautiful tank battle game with sound effects and English UI"
