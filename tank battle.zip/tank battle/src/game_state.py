from enum import Enum
from typing import Optional

class GameState(Enum):
    MENU = "menu"
    PLAYING = "playing"
    PAUSED = "paused"
    GAME_OVER = "game_over"
    LOADING = "loading"

class GameStateManager:
    def __init__(self):
        self.current_state = GameState.MENU
        self.previous_state: Optional[GameState] = None
        self.state_changed = False
    
    def set_state(self, new_state: GameState):
        if new_state != self.current_state:
            self.previous_state = self.current_state
            self.current_state = new_state
            self.state_changed = True
            print(f"Game state changed: {self.previous_state} -> {self.current_state}")
    
    def is_state(self, state: GameState) -> bool:
        return self.current_state == state
    
    def is_any_state(self, *states: GameState) -> bool:
        return self.current_state in states
    
    def get_current_state(self) -> GameState:
        return self.current_state
    
    def get_previous_state(self) -> Optional[GameState]:
        return self.previous_state
    
    def has_state_changed(self) -> bool:
        changed = self.state_changed
        self.state_changed = False
        return changed
    
    def toggle_pause(self):
        if self.current_state == GameState.PLAYING:
            self.set_state(GameState.PAUSED)
        elif self.current_state == GameState.PAUSED:
            self.set_state(GameState.PLAYING)
    
    def can_transition_to(self, target_state: GameState) -> bool:
        valid_transitions = {
            GameState.MENU: [GameState.PLAYING, GameState.LOADING],
            GameState.PLAYING: [GameState.PAUSED, GameState.GAME_OVER, GameState.MENU],
            GameState.PAUSED: [GameState.PLAYING, GameState.MENU],
            GameState.GAME_OVER: [GameState.MENU, GameState.PLAYING],
            GameState.LOADING: [GameState.MENU, GameState.PLAYING]
        }
        
        return target_state in valid_transitions.get(self.current_state, [])
