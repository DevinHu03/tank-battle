import pygame
import math
from typing import Dict, Optional, Tuple
from .bullet import Bullet

class Tank:
    def __init__(self, x: float, y: float, color: Tuple[int, int, int] = (255, 255, 255)):
        self.x = x
        self.y = y
        self.width = 40
        self.height = 40
        self.radius = 20
        self.color = color
        self.angle = 0
        self.speed = 100
        self.rotation_speed = 180
        self.max_health = 100
        self.health = self.max_health
        self.alive = True
        self.last_shot_time = 0
        self.shot_cooldown = 0.5
        self.bullet_speed = 300
        self.bullet_damage = 25
        self.moving_forward = False
        self.moving_backward = False
        self.turning_left = False
        self.turning_right = False

    def update(self, dt: float):
        if not self.alive:
            return
        if self.turning_left:
            self.angle -= self.rotation_speed * dt
        if self.turning_right:
            self.angle += self.rotation_speed * dt
        self.angle %= 360
        if self.moving_forward:
            self.move_forward(dt)
        if self.moving_backward:
            self.move_backward(dt)

    def move_forward(self, dt: float):
        angle_rad = math.radians(self.angle)
        dx = math.cos(angle_rad) * self.speed * dt
        dy = math.sin(angle_rad) * self.speed * dt
        nx = self.x + dx
        ny = self.y + dy
        if self.is_valid_position(nx, ny):
            self.x = nx
            self.y = ny

    def move_backward(self, dt: float):
        angle_rad = math.radians(self.angle)
        dx = -math.cos(angle_rad) * self.speed * dt * 0.5
        dy = -math.sin(angle_rad) * self.speed * dt * 0.5
        nx = self.x + dx
        ny = self.y + dy
        if self.is_valid_position(nx, ny):
            self.x = nx
            self.y = ny

    def is_valid_position(self, x: float, y: float) -> bool:
        return (self.radius <= x <= 1200 - self.radius and self.radius <= y <= 800 - self.radius)

    def try_shoot(self) -> Optional[Bullet]:
        current_time = pygame.time.get_ticks() / 1000.0
        if current_time - self.last_shot_time >= self.shot_cooldown:
            self.last_shot_time = current_time
            return self.shoot()
        return None

    def shoot(self) -> Bullet:
        angle_rad = math.radians(self.angle)
        bx = self.x + math.cos(angle_rad) * (self.radius + 5)
        by = self.y + math.sin(angle_rad) * (self.radius + 5)
        vx = math.cos(angle_rad) * self.bullet_speed
        vy = math.sin(angle_rad) * self.bullet_speed
        return Bullet(bx, by, vx, vy, self.bullet_damage, "unknown")

    def take_damage(self, damage: int):
        old = self.health
        self.health -= damage
        if self.health <= 0:
            self.health = 0
            self.alive = False
        print(f"Tank took {damage} damage: {old} -> {self.health} (alive: {self.alive})")

    def heal(self, amount: int):
        self.health = min(self.max_health, self.health + amount)

    def render(self, screen: pygame.Surface):
        if not self.alive:
            return
        surf = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        body = pygame.Rect(5, 10, 30, 20)
        pygame.draw.rect(surf, self.color, body)
        pygame.draw.rect(surf, (0, 0, 0), body, 2)
        track_left = pygame.Rect(0, 8, 4, 24)
        track_right = pygame.Rect(36, 8, 4, 24)
        pygame.draw.rect(surf, (100, 100, 100), track_left)
        pygame.draw.rect(surf, (100, 100, 100), track_right)
        turret_center = (self.width // 2, self.height // 2)
        pygame.draw.circle(surf, self.color, turret_center, 8)
        pygame.draw.circle(surf, (0, 0, 0), turret_center, 8, 2)
        barrel_len = 20
        end_x = turret_center[0] + barrel_len
        end_y = turret_center[1]
        pygame.draw.line(surf, (50, 50, 50), turret_center, (end_x, end_y), 4)
        rot = pygame.transform.rotate(surf, -self.angle)
        rect = rot.get_rect()
        rect.center = (self.x, self.y)
        screen.blit(rot, rect)
        self.render_health_bar(screen)

    def render_health_bar(self, screen: pygame.Surface):
        if not self.alive or self.health == self.max_health:
            return
        w = 40
        h = 6
        x = self.x - w // 2
        y = self.y - self.radius - 15
        bg = pygame.Rect(x, y, w, h)
        pygame.draw.rect(screen, (255, 0, 0), bg)
        ratio = self.health / self.max_health
        hw = int(w * ratio)
        hr = pygame.Rect(x, y, hw, h)
        color = (0, 255, 0) if ratio > 0.5 else (255, 255, 0) if ratio > 0.25 else (255, 0, 0)
        pygame.draw.rect(screen, color, hr)
        pygame.draw.rect(screen, (0, 0, 0), bg, 1)

class PlayerTank(Tank):
    def __init__(self, x: float, y: float, controls: Dict[str, int], color: Tuple[int, int, int] = (0, 255, 0)):
        super().__init__(x, y, color)
        self.controls = controls
        self.initial_x = x
        self.initial_y = y
        self.initial_color = color
        self.max_health = 150
        self.health = self.max_health
        self.shot_cooldown = 0.3
        self.speed = 120

    def update(self, dt: float):
        if not self.alive:
            return
        keys = pygame.key.get_pressed()
        self.moving_forward = False
        self.moving_backward = False
        self.turning_left = False
        self.turning_right = False
        if keys[self.controls['up']]:
            self.moving_forward = True
        if keys[self.controls['down']]:
            self.moving_backward = True
        if keys[self.controls['left']]:
            self.turning_left = True
        if keys[self.controls['right']]:
            self.turning_right = True
        super().update(dt)
        if keys[self.controls['shoot']]:
            return self.try_shoot()
        return None

    def shoot(self) -> Bullet:
        angle_rad = math.radians(self.angle)
        bx = self.x + math.cos(angle_rad) * (self.radius + 5)
        by = self.y + math.sin(angle_rad) * (self.radius + 5)
        vx = math.cos(angle_rad) * self.bullet_speed
        vy = math.sin(angle_rad) * self.bullet_speed
        return Bullet(bx, by, vx, vy, self.bullet_damage, "player")

    def reset(self):
        self.x = self.initial_x
        self.y = self.initial_y
        self.angle = 0
        self.health = self.max_health
        self.alive = True
        self.last_shot_time = 0

class EnemyTank(Tank):
    def __init__(self, x: float, y: float, color: Tuple[int, int, int] = (255, 0, 0)):
        super().__init__(x, y, color)
        self.target_x = x
        self.target_y = y
        self.last_direction_change = 0
        self.direction_change_interval = 2.0
        self.ai_type = "aggressive"
        self.max_health = 75
        self.health = self.max_health
        self.shot_cooldown = 1.0
        self.speed = 80

    def update(self, dt: float):
        if not self.alive:
            return
        current_time = pygame.time.get_ticks() / 1000.0
        if current_time - self.last_direction_change >= self.direction_change_interval:
            self.update_ai_behavior()
            self.last_direction_change = current_time
        self.execute_ai_movement(dt)
        super().update(dt)

    def update_ai_behavior(self):
        import random
        self.target_x = random.randint(50, 1150)
        self.target_y = random.randint(50, 750)
        ai_types = ["aggressive", "patrol", "defensive"]
        self.ai_type = random.choice(ai_types)

    def execute_ai_movement(self, dt: float):
        dx = self.target_x - self.x
        dy = self.target_y - self.y
        distance = math.sqrt(dx*dx + dy*dy)
        if distance > 20:
            target_angle = math.degrees(math.atan2(dy, dx))
            angle_diff = target_angle - self.angle
            while angle_diff > 180:
                angle_diff -= 360
            while angle_diff < -180:
                angle_diff += 360
            if abs(angle_diff) > 5:
                if angle_diff > 0:
                    self.turning_right = True
                else:
                    self.turning_left = True
            else:
                self.moving_forward = True

    def shoot(self) -> Bullet:
        angle_rad = math.radians(self.angle)
        bx = self.x + math.cos(angle_rad) * (self.radius + 5)
        by = self.y + math.sin(angle_rad) * (self.radius + 5)
        vx = math.cos(angle_rad) * self.bullet_speed
        vy = math.sin(angle_rad) * self.bullet_speed
        return Bullet(bx, by, vx, vy, self.bullet_damage, "enemy")
