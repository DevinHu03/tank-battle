import pygame
import math
from typing import Tuple

class Bullet:
    def __init__(self, x: float, y: float, velocity_x: float, velocity_y: float, 
                 damage: int = 25, owner_type: str = "player"):
        self.x = x
        self.y = y
        self.velocity_x = velocity_x
        self.velocity_y = velocity_y
        self.damage = damage
        self.owner_type = owner_type
        self.radius = 3
        self.alive = True
        self.max_lifetime = 3.0
        self.lifetime = 0.0
        self.color = (255, 255, 0) if owner_type == "player" else (255, 100, 100)
    
    def update(self, dt: float):
        if not self.alive:
            return
        self.x += self.velocity_x * dt
        self.y += self.velocity_y * dt
        self.lifetime += dt
        if self.lifetime >= self.max_lifetime:
            self.alive = False
        if (self.x < 0 or self.x > 1200 or 
            self.y < 0 or self.y > 800):
            self.alive = False
    
    def render(self, screen: pygame.Surface):
        if not self.alive:
            return
        pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), self.radius)
        trail_length = 10
        angle = math.atan2(self.velocity_y, self.velocity_x)
        trail_end_x = self.x - math.cos(angle) * trail_length
        trail_end_y = self.y - math.sin(angle) * trail_length
        trail_color = tuple(c // 2 for c in self.color)
        pygame.draw.line(screen, trail_color, 
                        (trail_end_x, trail_end_y), (self.x, self.y), 2)
        pygame.draw.circle(screen, (0, 0, 0), (int(self.x), int(self.y)), self.radius, 1)
