import pygame
import os
import pygame
import os
from typing import Dict
import math
import random
import array

class SoundManager:
    def __init__(self):
        pygame.mixer.pre_init(frequency=22050, size=-16, channels=2, buffer=512)
        pygame.mixer.init()
        self.sounds: Dict[str, pygame.mixer.Sound] = {}
        self.music_volume = 0.7
        self.sound_volume = 0.8
        self.enabled = True
        self._load()

    def _load(self):
        sounds_dir = "assets/sounds"
        os.makedirs(sounds_dir, exist_ok=True)
        names = ["shoot","enemy_shoot","explosion","tank_move","powerup","menu_select","game_over","victory"]
        for n in names:
            path = os.path.join(sounds_dir, n+".wav")
            if os.path.exists(path):
                try:
                    self.sounds[n] = pygame.mixer.Sound(path)
                    continue
                except pygame.error:
                    pass
            self.sounds[n] = self._gen(n)

    def _gen(self, t: str) -> pygame.mixer.Sound:
        sr = 22050
        wave = []
        def env(val):
            return max(-1, min(1, val))
        if t == "shoot":
            d, f = 0.1, 800
            for i in range(int(sr*d)):
                tt = i/sr
                wave.append((math.sin(2*math.pi*f*tt)+(random.random()-0.5)*0.6)*math.exp(-tt*50))
        elif t == "enemy_shoot":
            d, f = 0.12, 600
            for i in range(int(sr*d)):
                tt = i/sr
                wave.append((math.sin(2*math.pi*f*tt)+(random.random()-0.5)*0.4)*math.exp(-tt*33))
        elif t == "explosion":
            d = 0.5
            for i in range(int(sr*d)):
                tt = i/sr
                wave.append((random.random()-0.5)*2.0*math.exp(-tt*6))
        elif t == "tank_move":
            d, f = 0.3, 50
            for i in range(int(sr*d)):
                tt = i/sr
                wave.append((math.sin(2*math.pi*f*tt)+(random.random()-0.5))*0.3)
        elif t == "powerup":
            d = 0.3
            for i in range(int(sr*d)):
                tt = i/sr
                f = 400 + 400*tt/d
                wave.append(math.sin(2*math.pi*f*tt)*math.exp(-tt*6.67))
        elif t == "menu_select":
            d, f = 0.1, 1000
            for i in range(int(sr*d)):
                tt = i/sr
                wave.append(math.sin(2*math.pi*f*tt)*math.exp(-tt*80))
        elif t in ("game_over","victory"):
            d = 1.0
            freqs = [523,659,784] if t=="victory" else [220,277,330]
            for i in range(int(sr*d)):
                tt = i/sr
                val = sum(math.sin(2*math.pi*f*tt) for f in freqs)/len(freqs)
                wave.append(val*math.exp(-tt))
        else:
            d, f = 0.1, 440
            for i in range(int(sr*d)):
                tt = i/sr
                wave.append(math.sin(2*math.pi*f*tt)*math.exp(-tt*50))
        m = max(abs(x) for x in wave) if wave else 1
        data = [int(env(x/m*0.3)*32767) for x in wave]
        return pygame.mixer.Sound(array.array('h', data))

    def play_sound(self, name: str, volume: float = 1.0):
        if not self.enabled or name not in self.sounds:
            return
        s = self.sounds[name]
        s.set_volume(min(1.0, self.sound_volume*volume))
        s.play()

    def play_shoot(self): self.play_sound("shoot",0.6)
    def play_enemy_shoot(self): self.play_sound("enemy_shoot",0.5)
    def play_explosion(self): self.play_sound("explosion",0.8)
    def play_tank_move(self): self.play_sound("tank_move",0.3)
    def play_powerup(self): self.play_sound("powerup",0.7)
    def play_menu_select(self): self.play_sound("menu_select",0.5)
    def play_game_over(self): self.play_sound("game_over",1.0)
    def play_victory(self): self.play_sound("victory",1.0)

    def set_sound_volume(self, volume: float): self.sound_volume = max(0.0, min(1.0, volume))
    def set_music_volume(self, volume: float):
        self.music_volume = max(0.0, min(1.0, volume))
        pygame.mixer.music.set_volume(self.music_volume)
    def toggle_sound(self):
        self.enabled = not self.enabled
        return self.enabled
    def cleanup(self): pygame.mixer.quit()
    def cleanup(self):
        pygame.mixer.quit()
