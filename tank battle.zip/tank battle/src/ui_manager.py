"""
UI Manager
"""

import pygame
import math
from typing import List, Tuple, Optional, Dict, Any
from .game_state import GameState

class Button:
    def __init__(self, x: int, y: int, width: int, height: int, text: str, 
                 font: pygame.font.Font, color: Tuple[int, int, int] = (100, 100, 100),
                 text_color: Tuple[int, int, int] = (255, 255, 255)):
        """按钮类"""
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.font = font
        self.color = color
        self.text_color = text_color
        self.hover_color = tuple(min(255, c + 50) for c in color)
        self.is_hovered = False
        self.is_pressed = False
    
    def handle_event(self, event: pygame.event.Event) -> bool:
        """处理按钮事件"""
        if event.type == pygame.MOUSEMOTION:
            self.is_hovered = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1 and self.rect.collidepoint(event.pos):
                self.is_pressed = True
                return True
        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1:
                self.is_pressed = False
        return False
    
    def render(self, screen: pygame.Surface):
        """渲染按钮"""
        color = self.hover_color if self.is_hovered else self.color
        if self.is_pressed:
            color = tuple(max(0, c - 30) for c in color)
        
        # 绘制按钮背景
        pygame.draw.rect(screen, color, self.rect)
        pygame.draw.rect(screen, (255, 255, 255), self.rect, 2)
        
        # 绘制按钮文本
        text_surface = self.font.render(self.text, True, self.text_color)
        text_rect = text_surface.get_rect(center=self.rect.center)
        screen.blit(text_surface, text_rect)


class UIManager:
    def __init__(self, language_manager, sound_manager):
        """UI管理器初始化"""
        self.language_manager = language_manager
        self.sound_manager = sound_manager
        
        # 字体
        pygame.font.init()
        try:
            # 尝试使用系统字体
            self.font_large = pygame.font.SysFont('arial', 48)
            self.font_medium = pygame.font.SysFont('arial', 32)
            self.font_small = pygame.font.SysFont('arial', 24)
        except:
            # 回退到默认字体
            self.font_large = pygame.font.Font(None, 48)
            self.font_medium = pygame.font.Font(None, 32)
            self.font_small = pygame.font.Font(None, 24)
        
        # 菜单相关
        self.menu_buttons: List[Button] = []
        self.selected_button_index = 0
        self.menu_background_alpha = 0
        self.menu_animation_time = 0
        
        # HUD相关
        self.hud_elements: Dict[str, Any] = {}
        
        # 创建菜单按钮
        self.create_menu_buttons()
    
    def create_menu_buttons(self):
        """Create menu buttons"""
        screen_width = 1200
        screen_height = 800
        button_width = 200
        button_height = 50
        button_spacing = 70
        
        start_y = screen_height // 2 - 50  # 调整起始位置，因为只有两个按钮
        center_x = screen_width // 2 - button_width // 2
        
        # 按钮配置 - 只保留开始游戏和退出
        button_configs = [
            ("start_game", start_y),
            ("quit", start_y + button_spacing)
        ]
        
        self.menu_buttons.clear()
        for text_key, y in button_configs:
            text = self.language_manager.get_text(text_key)
            button = Button(center_x, y, button_width, button_height, 
                          text, self.font_medium)
            self.menu_buttons.append(button)
    
    def handle_menu_event(self, event: pygame.event.Event, game):
        """处理菜单事件"""
        # 处理按钮点击
        for i, button in enumerate(self.menu_buttons):
            if button.handle_event(event):
                self.selected_button_index = i
                self.sound_manager.play_menu_select()
                self.execute_menu_action(i, game)
        
        # 处理键盘导航
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                self.selected_button_index = (self.selected_button_index - 1) % len(self.menu_buttons)
                self.sound_manager.play_menu_select()
            elif event.key == pygame.K_DOWN:
                self.selected_button_index = (self.selected_button_index + 1) % len(self.menu_buttons)
                self.sound_manager.play_menu_select()
            elif event.key == pygame.K_RETURN:
                self.sound_manager.play_menu_select()
                self.execute_menu_action(self.selected_button_index, game)
    
    def execute_menu_action(self, button_index: int, game):
        """Execute menu action"""
        if button_index == 0:  # Start Game
            game.state_manager.set_state(GameState.PLAYING)
        elif button_index == 1:  # Quit
            import sys
            pygame.quit()
            sys.exit()
    
    def update_menu(self, dt: float):
        """Update menu animation"""
        self.menu_animation_time += dt
        
        # Update background transparency
        self.menu_background_alpha = min(180, self.menu_background_alpha + 200 * dt)
        
        # Update button text
        for i, button in enumerate(self.menu_buttons):
            if i == 0:
                button.text = self.language_manager.get_text("start_game")
            elif i == 1:
                button.text = self.language_manager.get_text("quit")
    
    def render_menu(self, screen: pygame.Surface):
        """渲染主菜单"""
        screen_width = screen.get_width()
        screen_height = screen.get_height()
        
        # 渲染背景
        self.render_menu_background(screen)
        
        # 渲染标题
        title_text = self.language_manager.get_text("game_title")
        title_surface = self.font_large.render(title_text, True, (255, 255, 255))
        title_rect = title_surface.get_rect(center=(screen_width // 2, 150))
        
        # 标题动画效果
        title_offset = math.sin(self.menu_animation_time * 2) * 5
        title_rect.y += title_offset
        screen.blit(title_surface, title_rect)
        
        # 渲染按钮
        for i, button in enumerate(self.menu_buttons):
            # 高亮选中的按钮
            if i == self.selected_button_index:
                highlight_rect = button.rect.copy()
                highlight_rect.inflate_ip(10, 10)
                pygame.draw.rect(screen, (255, 255, 0), highlight_rect, 3)
            
            button.render(screen)
    
    def render_menu_background(self, screen: pygame.Surface):
        """渲染菜单背景"""
        # 半透明覆盖层
        overlay = pygame.Surface(screen.get_size())
        overlay.set_alpha(self.menu_background_alpha)
        overlay.fill((0, 0, 50))
        screen.blit(overlay, (0, 0))
        
        # 动态背景图案
        self.render_animated_background(screen)
    
    def render_animated_background(self, screen: pygame.Surface):
        """渲染动态背景"""
        screen_width = screen.get_width()
        screen_height = screen.get_height()
        
        # 移动的网格线
        grid_size = 100
        offset_x = (self.menu_animation_time * 20) % grid_size
        offset_y = (self.menu_animation_time * 15) % grid_size
        
        line_color = (0, 100, 150, 50)
        for x in range(-grid_size, screen_width + grid_size, grid_size):
            start_pos = (x + offset_x, 0)
            end_pos = (x + offset_x, screen_height)
            pygame.draw.line(screen, line_color[:3], start_pos, end_pos, 1)
        
        for y in range(-grid_size, screen_height + grid_size, grid_size):
            start_pos = (0, y + offset_y)
            end_pos = (screen_width, y + offset_y)
            pygame.draw.line(screen, line_color[:3], start_pos, end_pos, 1)
    
    def render_hud(self, screen: pygame.Surface, game):
        """渲染游戏HUD"""
        # 渲染玩家信息
        self.render_player_info(screen, game)
        
        # 渲染游戏信息
        self.render_game_info(screen, game)
        
        # 渲染小地图（可选）
        # self.render_minimap(screen, game)
    
    def render_player_info(self, screen: pygame.Surface, game):
        """渲染玩家信息"""
        y_offset = 10
        
        for i, tank in enumerate(game.player_tanks):
            if not tank.alive:
                continue
            
            x_offset = 10 + i * 200
            
            # 玩家标签
            player_text = self.language_manager.get_text(f"player{i+1}")
            player_surface = self.font_small.render(player_text, True, tank.color)
            screen.blit(player_surface, (x_offset, y_offset))
            
            # 血量条
            health_bar_width = 150
            health_bar_height = 10
            health_ratio = tank.health / tank.max_health
            
            # 背景
            health_bg_rect = pygame.Rect(x_offset, y_offset + 25, health_bar_width, health_bar_height)
            pygame.draw.rect(screen, (100, 0, 0), health_bg_rect)
            
            # 血量
            health_width = int(health_bar_width * health_ratio)
            health_rect = pygame.Rect(x_offset, y_offset + 25, health_width, health_bar_height)
            health_color = (0, 255, 0) if health_ratio > 0.5 else (255, 255, 0) if health_ratio > 0.25 else (255, 0, 0)
            pygame.draw.rect(screen, health_color, health_rect)
            
            # 边框
            pygame.draw.rect(screen, (255, 255, 255), health_bg_rect, 1)
            
            # 血量数值
            health_text = f"{tank.health}/{tank.max_health}"
            health_surface = self.font_small.render(health_text, True, (255, 255, 255))
            screen.blit(health_surface, (x_offset, y_offset + 40))
    
    def render_game_info(self, screen: pygame.Surface, game):
        """渲染游戏信息"""
        screen_width = screen.get_width()
        
        # 得分
        score_text = f"{self.language_manager.get_text('score')}: {game.score}"
        score_surface = self.font_medium.render(score_text, True, (255, 255, 255))
        score_rect = score_surface.get_rect(topright=(screen_width - 10, 10))
        screen.blit(score_surface, score_rect)
        
        # 关卡
        level_text = f"{self.language_manager.get_text('level')}: {game.current_level}"
        level_surface = self.font_medium.render(level_text, True, (255, 255, 255))
        level_rect = level_surface.get_rect(topright=(screen_width - 10, 45))
        screen.blit(level_surface, level_rect)
        
        # 敌人计数
        enemies_left = game.enemies_per_level - game.enemies_killed
        enemy_text = f"{self.language_manager.get_text('enemy')}: {enemies_left}"
        enemy_surface = self.font_medium.render(enemy_text, True, (255, 255, 255))
        enemy_rect = enemy_surface.get_rect(topright=(screen_width - 10, 80))
        screen.blit(enemy_surface, enemy_rect)
    
    def render_pause_menu(self, screen: pygame.Surface):
        """渲染暂停菜单"""
        # 半透明覆盖层
        overlay = pygame.Surface(screen.get_size())
        overlay.set_alpha(150)
        overlay.fill((0, 0, 0))
        screen.blit(overlay, (0, 0))
        
        # 暂停文本
        pause_text = self.language_manager.get_text("pause")
        pause_surface = self.font_large.render(pause_text, True, (255, 255, 255))
        pause_rect = pause_surface.get_rect(center=(screen.get_width() // 2, screen.get_height() // 2 - 50))
        screen.blit(pause_surface, pause_rect)
        
        # 控制提示
        controls = [
            "ESC - " + self.language_manager.get_text("resume"),
            "R - " + self.language_manager.get_text("restart"),
            "F1 - " + self.language_manager.get_text("language")
        ]
        
        y_offset = screen.get_height() // 2
        for i, control in enumerate(controls):
            control_surface = self.font_small.render(control, True, (200, 200, 200))
            control_rect = control_surface.get_rect(center=(screen.get_width() // 2, y_offset + i * 30))
            screen.blit(control_surface, control_rect)
    
    def render_game_over(self, screen: pygame.Surface, score: int):
        """渲染游戏结束界面"""
        # 半透明覆盖层
        overlay = pygame.Surface(screen.get_size())
        overlay.set_alpha(180)
        overlay.fill((50, 0, 0))
        screen.blit(overlay, (0, 0))
        
        # 游戏结束文本
        game_over_text = self.language_manager.get_text("game_over")
        game_over_surface = self.font_large.render(game_over_text, True, (255, 255, 255))
        game_over_rect = game_over_surface.get_rect(center=(screen.get_width() // 2, screen.get_height() // 2 - 100))
        screen.blit(game_over_surface, game_over_rect)
        
        # 最终得分
        score_text = f"{self.language_manager.get_text('score')}: {score}"
        score_surface = self.font_medium.render(score_text, True, (255, 255, 255))
        score_rect = score_surface.get_rect(center=(screen.get_width() // 2, screen.get_height() // 2 - 50))
        screen.blit(score_surface, score_rect)
        
        # 控制提示
        restart_text = "R - " + self.language_manager.get_text("restart")
        menu_text = "ESC - " + self.language_manager.get_text("back_to_menu")
        
        restart_surface = self.font_small.render(restart_text, True, (200, 200, 200))
        restart_rect = restart_surface.get_rect(center=(screen.get_width() // 2, screen.get_height() // 2 + 20))
        screen.blit(restart_surface, restart_rect)
        
        menu_surface = self.font_small.render(menu_text, True, (200, 200, 200))
        menu_rect = menu_surface.get_rect(center=(screen.get_width() // 2, screen.get_height() // 2 + 50))
        screen.blit(menu_surface, menu_rect)
