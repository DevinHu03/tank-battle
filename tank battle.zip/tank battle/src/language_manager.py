class LanguageManager:
    def __init__(self):
        self.current_language = "en"
        self.languages = {
            "en": {
                "game_title": "Tank Battle",
                "start_game": "Start Game",
                "quit": "Quit",
                "game_over": "Game Over",
                "victory": "Victory!",
                "defeat": "Defeat!",
                "score": "Score",
                "level": "Level",
                "lives": "Lives",
                "pause": "Pause",
                "resume": "Resume",
                "restart": "Restart",
                "back_to_menu": "Back to Menu",
                "player1": "Player 1",
                "player2": "Player 2",
                "enemy": "Enemy",
                "health": "Health",
                "ammo": "Ammo",
                "sound": "Sound",
                "music": "Music",
                "volume": "Volume",
                "controls": "Controls",
                "move": "Move",
                "shoot": "Shoot",
                "wasd_move": "WASD to move",
                "space_shoot": "Space to shoot",
                "arrow_move": "Arrow keys to move",
                "enter_shoot": "Enter to shoot",
                "loading": "Loading..."
            }
        }
    
    def get_text(self, key: str) -> str:
        return self.languages.get(self.current_language, {}).get(key, key)
    
    def toggle_language(self):
        pass
    
    def set_language(self, language: str):
        self.current_language = "en"
    
    def get_current_language(self) -> str:
        return self.current_language
