import pygame
import math
import random
from typing import List, Tuple

class Particle:
    def __init__(self, x: float, y: float, velocity_x: float, velocity_y: float, 
                 color: Tuple[int, int, int], lifetime: float):
        self.x = x
        self.y = y
        self.velocity_x = velocity_x
        self.velocity_y = velocity_y
        self.color = color
        self.max_lifetime = lifetime
        self.lifetime = 0.0
        self.size = random.uniform(2, 6)
        self.alive = True
    
    def update(self, dt: float):
        if not self.alive:
            return
        self.x += self.velocity_x * dt
        self.y += self.velocity_y * dt
        self.velocity_y += 100 * dt
        self.velocity_x *= 0.98
        self.velocity_y *= 0.98
        self.lifetime += dt
        if self.lifetime >= self.max_lifetime:
            self.alive = False
        self.size *= 0.99
        if self.size < 0.5:
            self.alive = False
    
    def render(self, screen: pygame.Surface):
        if not self.alive:
            return
        alpha = int(255 * (1 - self.lifetime / self.max_lifetime))
        alpha = max(0, min(255, alpha))
        particle_surface = pygame.Surface((self.size * 2, self.size * 2), pygame.SRCALPHA)
        color_with_alpha = (*self.color, alpha)
        pygame.draw.circle(particle_surface, color_with_alpha, 
                          (self.size, self.size), self.size)
        
        screen.blit(particle_surface, (self.x - self.size, self.y - self.size))


class Explosion:
    def __init__(self, x: float, y: float, size: str = "normal"):
        self.x = x
        self.y = y
        self.size_type = size
        self.particles: List[Particle] = []
        self.alive = True
        self.max_lifetime = 2.0
        self.lifetime = 0.0
        
        if size == "small":
            particle_count = 15
            max_speed = 100
            max_lifetime = 1.0
        elif size == "large":
            particle_count = 50
            max_speed = 200
            max_lifetime = 3.0
        else:  # normal
            particle_count = 30
            max_speed = 150
            max_lifetime = 2.0
        
        self.max_lifetime = max_lifetime
        
        self.create_particles(particle_count, max_speed)
    
    def create_particles(self, count: int, max_speed: float):
        colors = [
            (255, 255, 0),
            (255, 165, 0),
            (255, 69, 0),
            (255, 0, 0),
            (139, 69, 19),
            (105, 105, 105),
        ]
        for _ in range(count):
            angle = random.uniform(0, 2 * math.pi)
            speed = random.uniform(max_speed * 0.3, max_speed)
            velocity_x = math.cos(angle) * speed
            velocity_y = math.sin(angle) * speed
            color = random.choice(colors)
            lifetime = random.uniform(self.max_lifetime * 0.5, self.max_lifetime)
            particle = Particle(self.x, self.y, velocity_x, velocity_y, color, lifetime)
            self.particles.append(particle)
    
    def update(self, dt: float):
        if not self.alive:
            return
        for particle in self.particles[:]:
            particle.update(dt)
            if not particle.alive:
                self.particles.remove(particle)
        self.lifetime += dt
        if self.lifetime >= self.max_lifetime or len(self.particles) == 0:
            self.alive = False
    
    def render(self, screen: pygame.Surface):
        if not self.alive:
            return
        for particle in self.particles:
            particle.render(screen)
        if self.lifetime < 0.1:
            flash_radius = int(50 * (1 - self.lifetime / 0.1))
            flash_surface = pygame.Surface((flash_radius * 2, flash_radius * 2), pygame.SRCALPHA)
            flash_color = (255, 255, 255, int(100 * (1 - self.lifetime / 0.1)))
            pygame.draw.circle(flash_surface, flash_color, 
                             (flash_radius, flash_radius), flash_radius)
            screen.blit(flash_surface, (self.x - flash_radius, self.y - flash_radius))
