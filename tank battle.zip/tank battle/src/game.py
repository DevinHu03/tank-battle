import pygame
import random
import math
from typing import List, Tuple, Dict, Any
from .tank import Tank, PlayerTank, EnemyTank
from .bullet import Bullet
from .explosion import Explosion
from .powerup import PowerUp
from .sound_manager import SoundManager
from .ui_manager import UIManager
from .game_state import GameState, GameStateManager

class Game:
    def __init__(self, screen: pygame.Surface, language_manager):
        self.screen = screen
        self.screen_width = screen.get_width()
        self.screen_height = screen.get_height()
        self.language_manager = language_manager
        self.state_manager = GameStateManager()
        self.sound_manager = SoundManager()
        self.ui_manager = UIManager(language_manager, self.sound_manager)
        self.player_tanks: List[PlayerTank] = []
        self.enemy_tanks: List[EnemyTank] = []
        self.bullets: List[Bullet] = []
        self.explosions: List[Explosion] = []
        self.powerups: List[PowerUp] = []
        self.max_enemies = 6
        self.current_level = 1
        self.score = 0
        self.enemies_killed = 0
        self.enemies_per_level = 20
        self.init_game()
    
    def init_game(self):
        
        player1 = PlayerTank(
            x=100, y=self.screen_height - 100,
            controls={
                'up': pygame.K_w,
                'down': pygame.K_s,
                'left': pygame.K_a,
                'right': pygame.K_d,
                'shoot': pygame.K_SPACE
            },
            color=(0, 255, 0)
        )
        self.player_tanks.append(player1)
        player2 = PlayerTank(
            x=200, y=self.screen_height - 100,
            controls={
                'up': pygame.K_UP,
                'down': pygame.K_DOWN,
                'left': pygame.K_LEFT,
                'right': pygame.K_RIGHT,
                'shoot': pygame.K_RETURN
            },
            color=(0, 0, 255)
        )
        self.player_tanks.append(player2)
        self.spawn_enemies()
    
    def spawn_enemies(self):
        spawn_positions = [
            (50, 50), (self.screen_width // 2, 50), (self.screen_width - 50, 50)
        ]
        
        while len(self.enemy_tanks) < min(self.max_enemies, self.enemies_per_level - self.enemies_killed):
            pos = random.choice(spawn_positions)
            too_close = False
            for player in self.player_tanks:
                if player.alive and math.sqrt((pos[0] - player.x)**2 + (pos[1] - player.y)**2) < 200:
                    too_close = True
                    break
            
            if not too_close:
                enemy = EnemyTank(pos[0], pos[1])
                self.enemy_tanks.append(enemy)
                break
    
    def handle_event(self, event: pygame.event.Event):
        if self.state_manager.current_state == GameState.MENU:
            self.ui_manager.handle_menu_event(event, self)
        elif self.state_manager.current_state == GameState.PLAYING:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.state_manager.set_state(GameState.PAUSED)
        elif self.state_manager.current_state == GameState.PAUSED:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.state_manager.set_state(GameState.PLAYING)
                elif event.key == pygame.K_r:
                    self.restart_game()
        elif self.state_manager.current_state == GameState.GAME_OVER:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    self.restart_game()
                elif event.key == pygame.K_ESCAPE:
                    self.state_manager.set_state(GameState.MENU)
    
    def update(self, dt: float):
        if self.state_manager.current_state == GameState.PLAYING:
            self.update_gameplay(dt)
        elif self.state_manager.current_state == GameState.MENU:
            self.ui_manager.update_menu(dt)
    
    def update_gameplay(self, dt: float):
        
        for tank in self.player_tanks:
            if tank.alive:
                bullet = tank.update(dt)
                if bullet:
                    self.bullets.append(bullet)
                    self.sound_manager.play_shoot()
        for tank in self.enemy_tanks[:]:
            if tank.alive:
                tank.update(dt)
                if random.random() < 0.01:
                    new_bullet = tank.try_shoot()
                    if new_bullet:
                        self.bullets.append(new_bullet)
                        self.sound_manager.play_enemy_shoot()
            else:
                self.enemy_tanks.remove(tank)
                self.enemies_killed += 1
                self.score += 100
        
        for bullet in self.bullets[:]:
            bullet.update(dt)
            if not bullet.alive:
                self.bullets.remove(bullet)
        for explosion in self.explosions[:]:
            explosion.update(dt)
            if not explosion.alive:
                self.explosions.remove(explosion)
        for powerup in self.powerups[:]:
            powerup.update(dt)
            if not powerup.alive:
                self.powerups.remove(powerup)
        self.check_collisions()
        if len(self.enemy_tanks) < 3 and self.enemies_killed < self.enemies_per_level:
            self.spawn_enemies()
        self.check_game_state()
        if random.random() < 0.001:
            self.spawn_powerup()
    
    def check_collisions(self):
        
        for bullet in self.bullets[:]:
            if not bullet.alive:
                continue
            if bullet.owner_type == "player":
                for tank in self.enemy_tanks:
                    if tank.alive and self.check_collision(bullet, tank):
                        tank.take_damage(bullet.damage)
                        self.create_explosion(bullet.x, bullet.y)
                        bullet.alive = False
                        self.sound_manager.play_explosion()
                        if not tank.alive:
                            self.score += 100
                        break
            elif bullet.owner_type == "enemy":
                for tank in self.player_tanks:
                    if tank.alive and self.check_collision(bullet, tank):
                        tank.take_damage(bullet.damage)
                        self.create_explosion(bullet.x, bullet.y)
                        bullet.alive = False
                        self.sound_manager.play_explosion()
                        break
        for powerup in self.powerups[:]:
            if not powerup.alive:
                continue
            for tank in self.player_tanks:
                if tank.alive and self.check_collision(powerup, tank):
                    powerup.apply_effect(tank)
                    powerup.alive = False
                    self.sound_manager.play_powerup()
                    break
    
    def check_collision(self, obj1, obj2) -> bool:
        distance = math.sqrt((obj1.x - obj2.x)**2 + (obj1.y - obj2.y)**2)
        collision_distance = getattr(obj1, 'radius', 10) + getattr(obj2, 'radius', 20)
        return distance < collision_distance
    
    def create_explosion(self, x: float, y: float):
        explosion = Explosion(x, y)
        self.explosions.append(explosion)
    
    def spawn_powerup(self):
        x = random.randint(50, self.screen_width - 50)
        y = random.randint(50, self.screen_height - 50)
        powerup = PowerUp(x, y)
        self.powerups.append(powerup)
    
    def check_game_state(self):
        all_players_dead = all(not tank.alive for tank in self.player_tanks)
        if all_players_dead:
            self.state_manager.set_state(GameState.GAME_OVER)
            return
        if self.enemies_killed >= self.enemies_per_level and len(self.enemy_tanks) == 0:
            self.next_level()
    
    def next_level(self):
        self.current_level += 1
        self.enemies_killed = 0
        self.enemies_per_level += 5
        for tank in self.player_tanks:
            if tank.alive:
                tank.health = min(tank.max_health, tank.health + 50)
        self.bullets.clear()
        print(f"Level {self.current_level} started!")
    
    def restart_game(self):
        self.current_level = 1
        self.score = 0
        self.enemies_killed = 0
        self.enemies_per_level = 20
        self.enemy_tanks.clear()
        self.bullets.clear()
        self.explosions.clear()
        self.powerups.clear()
        for tank in self.player_tanks:
            tank.reset()
        self.spawn_enemies()
        self.state_manager.set_state(GameState.PLAYING)
    
    def update_language(self):
        self.ui_manager.language_manager = self.language_manager
    
    def render(self, screen: pygame.Surface):
        if self.state_manager.current_state == GameState.MENU:
            self.ui_manager.render_menu(screen)
        elif self.state_manager.current_state == GameState.PLAYING:
            self.render_gameplay(screen)
            self.ui_manager.render_hud(screen, self)
        elif self.state_manager.current_state == GameState.PAUSED:
            self.render_gameplay(screen)
            self.ui_manager.render_pause_menu(screen)
        elif self.state_manager.current_state == GameState.GAME_OVER:
            self.render_gameplay(screen)
            self.ui_manager.render_game_over(screen, self.score)
    
    def render_gameplay(self, screen: pygame.Surface):
        
        self.render_grid(screen)
        for tank in self.player_tanks:
            if tank.alive:
                tank.render(screen)
        for tank in self.enemy_tanks:
            if tank.alive:
                tank.render(screen)
        for bullet in self.bullets:
            if bullet.alive:
                bullet.render(screen)
        for explosion in self.explosions:
            if explosion.alive:
                explosion.render(screen)
        for powerup in self.powerups:
            if powerup.alive:
                powerup.render(screen)
    
    def render_grid(self, screen: pygame.Surface):
        grid_size = 50
        grid_color = (70, 70, 70)
        for x in range(0, self.screen_width, grid_size):
            pygame.draw.line(screen, grid_color, (x, 0), (x, self.screen_height))
        for y in range(0, self.screen_height, grid_size):
            pygame.draw.line(screen, grid_color, (0, y), (self.screen_width, y))
